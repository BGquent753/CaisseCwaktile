package com.innovorder.testtechnique

import android.telecom.Call
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import kotlinx.coroutines.*
import retrofit2.Response
import javax.security.auth.callback.Callback

class MainViewModel(
    private val service: DuckService = RestClient().getDuckService()
) : ViewModel() {
    lateinit var data: LiveData<List<Duck>>
    private  var _data : MutableLiveData<List<Duck>>

    init {
        _data = MutableLiveData<List<Duck>>()
        getDucks()
    }

    private fun getDucks() {
        _data.postValue(service.getAllDucks().execute().body()!!.ducks)
        data = _data
    }
}
