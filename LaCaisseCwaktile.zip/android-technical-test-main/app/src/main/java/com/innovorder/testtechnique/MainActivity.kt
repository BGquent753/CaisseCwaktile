package com.innovorder.testtechnique

import android.content.DialogInterface
import android.content.Intent
import android.media.MediaPlayer
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.innovorder.testtechnique.databinding.ActivityMainBinding
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: DucksAdapter
    private var couleur: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupRecyclerView()
        getInfoDuck()

            //coroutine qui va chercher les canards hors du main thread

            GlobalScope.launch{
                withContext(Dispatchers.IO){
                    val liste = viewModel.data.value
                    liste?.let{
                        launch(Dispatchers.Main){
                            adapter.submitList(it)

                            //Ne connaissant pas les différentes couleurs de canards existantes,
                            //j'ai parcouru le tableau de canard et noté toutes les couleurs
                            //ainsi que leur nombre d'apparition

                            val listeColor = ArrayList<String>()//liste des couleurs de canards
                            val count = ArrayList<Int>()//liste qui compte le nombre d'appartition des couleurs
                            for(i : Int in 0..liste.size-1){
                                val color: String = liste.get(i).color
                                if(listeColor.size != 0){
                                    var new = 0
                                    for(j: Int in 0..listeColor.size-1){
                                        if(color.equals(listeColor.get(j))){
                                            count.set(j, count.get(j)+1)
                                            break
                                        }
                                        else{
                                            new++
                                        }
                                    }
                                    if(new ==  listeColor.size){
                                        listeColor.add(color)
                                        count.add(1)
                                    }
                                }
                                else{
                                    listeColor.add(color)
                                    count.add(1)
                                }
                            }
                            var max = 0
                            var position = 0
                            for(i: Int in 0..count.size-1){
                                if(count.get(i) > max){
                                    max = count.get(i)
                                    position = i
                                }
                                else{
                                    continue
                                }
                            }
                            couleur = listeColor.get(position)
                            delay(1000)
                            binding.quackButton.text = couleur
                        }
                    }
                }
            }

        setupQuack()


    }

    private fun setupQuack() {
        val quackPlayer = MediaPlayer.create(this, R.raw.quack2)
        binding.quackButton.setOnClickListener {
            quackPlayer.start()
        }
    }

    fun getInfoDuck(){
        adapter = DucksAdapter()
        binding.recyclerview.adapter = adapter
        adapter.setOnItemClickListener(object : DucksAdapter.onItemClickListener{

            override fun onItemClick(position: Int) {

                val duckListe = viewModel.data.value
                var duck: Duck? = duckListe?.get(position)
                /*val intentDuck: Intent = Intent(this@MainActivity, DuckInfo::class.java)
                intentDuck.putExtra(duck?.name, "name")
                intentDuck.putExtra(duck?.color, "color")
                intentDuck.putExtra(duck?.image, "image")

                startActivity(intentDuck)*/

                val duckInfo = AlertDialog.Builder(this@MainActivity)
                duckInfo.setTitle("Duck Info")
                duckInfo.setMessage("Name:  "+duck?.name+"\nColor: "+duck?.color)
                duckInfo.setPositiveButton(android.R.string.yes) { dialogInterface: DialogInterface?, i: Int ->
                }
                duckInfo.show()
            }

        })
    }

    private fun setupRecyclerView() {
        val quackPlayer = MediaPlayer.create(this, R.raw.quack2)

        adapter = DucksAdapter()
        binding.recyclerview.adapter = adapter
        binding.recyclerview.layoutManager = LinearLayoutManager(this)

        binding.recyclerview.addOnScrollListener(object: RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                (binding.recyclerview.layoutManager as LinearLayoutManager)
                    .findFirstCompletelyVisibleItemPosition()
                    .also {
                        quackPlayer.start()
                    }
            }
        })
    }
}
