package com.innovorder.testtechnique

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DuckInfo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_duck_info)

        val intentInfo = getIntent()

        var nom: String? = ""
        var couleur: String? = ""
        var image: String? = ""

        if(intentInfo.hasExtra("name")){
            nom = intentInfo.getStringExtra("name")
        }
        if(intentInfo.hasExtra("color")){
            couleur = intentInfo.getStringExtra("color")
        }
        if(intentInfo.hasExtra("image")){
            image = intentInfo.getStringExtra("image")
        }

        //val duckImage = findViewById<ImageView>(R.id.image)
        val duckName = findViewById<TextView>(R.id.name)
        val duckColor = findViewById<TextView>(R.id.color)

        //duckImage.setImage
        duckName.text = nom
        duckColor.text = couleur
    }
}