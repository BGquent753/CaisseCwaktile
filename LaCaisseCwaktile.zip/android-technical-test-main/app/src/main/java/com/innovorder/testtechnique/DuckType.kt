package com.innovorder.testtechnique

enum class DuckType {
    GIF,
    JPEG
}
